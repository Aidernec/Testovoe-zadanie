<?php

$recepient = "wm.info@bk.ru";
$siteName = "Ajax-форма";

$name = trim($_POST["name"]);
$phone = trim($_POST["phone"]);
$message = trim($_POST["message"]);
$order = "Имя: $name \nphone: $phone \nmessage: $message";

$pagetitle = "Заявка с сайта \"$siteName\"";
mail($recepient, $pagetitle, $order, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

?>